// 
// Decompiled by Procyon v0.5.36
// 

package fr.sintlewe.particules.evants;

public class Movement
{
}
